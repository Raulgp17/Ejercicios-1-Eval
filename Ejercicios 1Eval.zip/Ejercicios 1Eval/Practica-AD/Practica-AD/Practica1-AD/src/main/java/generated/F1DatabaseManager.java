package generated;

import java.io.File;
import java.math.BigInteger;
import java.util.Iterator;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

public class F1DatabaseManager {

    public static void main(String[] args) {
        try {
            // 1. Crear contexto JAXB para la clase raíz
            JAXBContext context = JAXBContext.newInstance(F1Database.class);

            // 2. Crear un Unmarshaller para leer el XML
            Unmarshaller unmarshaller = context.createUnmarshaller();

            // 3. Leer archivo XML existente
            File xmlFile = new File("AD1T2024Raúl_GonzálezPerera_F1Database.xml");
            F1Database f1Database;

            if (xmlFile.exists()) {
                // Si el archivo XML existe, cargamos los datos
                f1Database = (F1Database) unmarshaller.unmarshal(xmlFile);
                System.out.println("Archivo XML cargado exitosamente.");
            } else {
                // Si no existe, creamos un nuevo objeto
                f1Database = new F1Database();
                System.out.println("No se encontró el archivo XML, se creó una nueva base de datos.");
            }

            // 4. Trabajar con los datos (agregar un equipo y pilotos de ejemplo)
            F1Database.Equipo nuevoEquipo = new F1Database.Equipo();
            nuevoEquipo.setNombre("Aston Martin");
            nuevoEquipo.setPais("Reino Unido");

            F1Database.Equipo.Piloto piloto1 = new F1Database.Equipo.Piloto();
            piloto1.setNombre("Fernando Alonso");
            piloto1.setEdad(BigInteger.valueOf(28));
            piloto1.setNacionalidad("Español");

            F1Database.Equipo.Piloto piloto2 = new F1Database.Equipo.Piloto();
            piloto2.setNombre("Lance Stroll");
            piloto2.setEdad(BigInteger.valueOf(26));
            piloto2.setNacionalidad("Canadiense");

            nuevoEquipo.getPiloto().add(piloto1);
            nuevoEquipo.getPiloto().add(piloto2);

            // Añadir el equipo a la base de datos
            f1Database.getEquipo().add(nuevoEquipo);

            // 5. Guardar los datos en un archivo XML
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.marshal(f1Database, new File("f1Database.xml"));

            System.out.println("Archivo XML guardado exitosamente.");

            // 6. Mostrar detalles de un equipo y sus pilotos
            mostrarEquipo(f1Database, "Alpine");

            // 7. Buscar y eliminar un piloto
            eliminarPiloto(f1Database, "Alpine", "Esteban Ocon");

            // 8. Eliminar un equipo completo
            eliminarEquipo(f1Database, "Mercedes");

            // 9. Guardar los cambios en el archivo XML
            marshaller.marshal(f1Database, new File("f1Database.xml"));
            System.out.println("Cambios guardados en el archivo XML.");

        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }

    // Mostrar equipo y pilotos por nombre de equipo
    private static void mostrarEquipo(F1Database f1Database, String nombreEquipo) {
        for (F1Database.Equipo equipo : f1Database.getEquipo()) {
            if (equipo.getNombre().equalsIgnoreCase(nombreEquipo)) {
                System.out.println("Equipo: " + equipo.getNombre());
                System.out.println("País: " + equipo.getPais());
                for (F1Database.Equipo.Piloto piloto : equipo.getPiloto()) {
                    System.out.println("Piloto: " + piloto.getNombre());
                    System.out.println("Edad: " + piloto.getEdad());
                    System.out.println("Nacionalidad: " + piloto.getNacionalidad());
                }
            }
        }
    }

    // Buscar y eliminar un piloto del equipo por nombre
    private static void eliminarPiloto(F1Database f1Database, String nombreEquipo, String nombrePiloto) {
        for (F1Database.Equipo equipo : f1Database.getEquipo()) {
            if (equipo.getNombre().equalsIgnoreCase(nombreEquipo)) {
                Iterator<F1Database.Equipo.Piloto> iter = equipo.getPiloto().iterator();
                while (iter.hasNext()) {
                    F1Database.Equipo.Piloto piloto = iter.next();
                    if (piloto.getNombre().equalsIgnoreCase(nombrePiloto)) {
                        iter.remove();
                        System.out.println("Piloto " + nombrePiloto + " eliminado del equipo " + nombreEquipo);
                        return;
                    }
                }
            }
        }
        System.out.println("Piloto no encontrado.");
    }

    // Buscar y eliminar un equipo completo por nombre
    private static void eliminarEquipo(F1Database f1Database, String nombreEquipo) {
        Iterator<F1Database.Equipo> iter = f1Database.getEquipo().iterator();
        while (iter.hasNext()) {
            F1Database.Equipo equipo = iter.next();
            if (equipo.getNombre().equalsIgnoreCase(nombreEquipo)) {
                iter.remove();
                System.out.println("Equipo " + nombreEquipo + " eliminado.");
                return;
            }
        }
        System.out.println("Equipo no encontrado.");
    }
}
