import java.io.File;
import java.io.FilenameFilter;
import java.util.Arrays;
import java.util.List;
import java.util.Comparator;

public class Filtros {

    // Filtro para archivos de audio (según extensiones dadas)
    public static class AudioFileFilter implements FilenameFilter {
        // Lista de extensiones consideradas "audio" (según el enunciado)
        private static final List<String> audioExtensions = Arrays.asList(".mp3", ".jpg", ".tif");

        // Método que define si el archivo cumple con las condiciones del filtro
        @Override
        public boolean accept(File dir, String name) {
            // Devuelve true si el nombre del archivo termina con una de las extensiones
            return audioExtensions.stream().anyMatch(name.toLowerCase()::endsWith);
        }

        // Método auxiliar que filtra archivos de audio en un directorio
        public File[] filterAudioFiles(File directory) {
            return directory.listFiles(new AudioFileFilter());
        }
    }

    // Filtro para archivos .exe que NO tienen permisos de ejecución
    public static class ExeFileNoExecPermissionFilter implements FilenameFilter {
        @Override
        public boolean accept(File dir, String name) {
            File file = new File(dir, name);
            // Verifica que sea .exe y que no tenga permiso de ejecución
            return name.toLowerCase().endsWith(".exe") && !file.canExecute();
        }

        // Método auxiliar que aplica el filtro a un directorio
        public File[] filterExeNoExecPermission(File directory) {
            return directory.listFiles(new ExeFileNoExecPermissionFilter());
        }
    }

    // Filtro para archivos de vídeo y devuelve los 4 más grandes
    public static class VideoFileFilter implements FilenameFilter {
        // Extensiones de vídeo permitidas
        private static final List<String> videoExtensions = Arrays.asList(".avi", ".mp4", ".mkv");

        @Override
        public boolean accept(File dir, String name) {
            // Verifica que el archivo tenga una extensión de vídeo válida
            return videoExtensions.stream().anyMatch(name.toLowerCase()::endsWith);
        }

        // Método que filtra, ordena por tamaño descendente y devuelve los 4 más grandes
        public File[] filterTop4LargestVideoFiles(File directory) {
            File[] videoFiles = directory.listFiles(new VideoFileFilter());
            if (videoFiles == null) return new File[0]; // Si no hay archivos, retorna vacío

            // Ordena los archivos por tamaño (de mayor a menor)
            Arrays.sort(videoFiles, Comparator.comparingLong(File::length).reversed());

            // Devuelve solo los 4 primeros (más grandes)
            return Arrays.stream(videoFiles).limit(4).toArray(File[]::new);
        }
    }

    // Filtro para archivos modificados en las últimas 24 horas
    public static class ModifiedLast24HoursFilter implements FilenameFilter {
        // 24 horas en milisegundos
        private static final long MILLIS_IN_24H = 24 * 60 * 60 * 1000L;

        @Override
        public boolean accept(File dir, String name) {
            File file = new File(dir, name);
            long currentTime = System.currentTimeMillis();
            // Devuelve true si el archivo fue modificado en las últimas 24 horas
            return file.lastModified() >= (currentTime - MILLIS_IN_24H);
        }

        // Método que aplica el filtro a un directorio
        public File[] filterModifiedLast24Hours(File directory) {
            return directory.listFiles(new ModifiedLast24HoursFilter());
        }
    }

    // Filtro para archivos por tamaño, usando categorías
    public static class SizeFileFilter implements FilenameFilter {
        private final long minSize; // Tamaño mínimo en bytes
        private final long maxSize; // Tamaño máximo en bytes

        // Constructor que recibe el tamaño mínimo y máximo
        public SizeFileFilter(long minSize, long maxSize) {
            this.minSize = minSize;
            this.maxSize = maxSize;
        }

        @Override
        public boolean accept(File dir, String name) {
            File file = new File(dir, name);
            long size = file.length(); // Obtiene el tamaño del archivo
            // Verifica que el tamaño esté dentro del rango
            return size >= minSize && size <= maxSize;
        }

        // Método estático para aplicar el filtro según una categoría textual
        public static File[] filterBySize(File directory, String sizeCategory) {
            SizeFileFilter sizeFilter;

            // Asigna valores de tamaño según la categoría
            switch (sizeCategory.toLowerCase()) {
                case "pequeño": // hasta 1 KB
                    sizeFilter = new SizeFileFilter(0, 1024);
                    break;
                case "mediano": // hasta 1 MB
                    sizeFilter = new SizeFileFilter(1025, 1024 * 1024);
                    break;
                case "grande": // hasta 1 GB
                    sizeFilter = new SizeFileFilter(1024 * 1024 + 1, 1024 * 1024 * 1024);
                    break;
                default: // "super" (más de 1 GB)
                    sizeFilter = new SizeFileFilter(1024 * 1024 * 1024 + 1, Long.MAX_VALUE);
                    break;
            }

            // Aplica el filtro al directorio
            return directory.listFiles(sizeFilter);
        }
    }
}
