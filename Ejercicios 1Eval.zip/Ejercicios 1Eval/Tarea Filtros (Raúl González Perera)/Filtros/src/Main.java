import java.io.File;

public class Main {

    public static void main(String[] args) {
    String path = "."; //Aqui se ha de introducir la ruta donde se encuentrenlos archivos
    File directory = new File(path);


    Filtros.AudioFileFilter audioFilter = new Filtros.AudioFileFilter();
    File[] audioFiles = audioFilter.filterAudioFiles(directory);
    System.out.println("Archivos de audio: " + (audioFiles != null ? audioFiles.length : 0));


    Filtros.ExeFileNoExecPermissionFilter exeFilter = new Filtros.ExeFileNoExecPermissionFilter();
    File[] nonExecExeFiles = exeFilter.filterExeNoExecPermission(directory);
    System.out.println(".exe sin permiso de ejecucción: " + (nonExecExeFiles != null ? nonExecExeFiles.length : 0));


    Filtros.VideoFileFilter videoFilter = new Filtros.VideoFileFilter();
    File[] largestVideoFiles = videoFilter.filterTop4LargestVideoFiles(directory);
    System.out.println("Los 4 videos mas pesados: " + (largestVideoFiles != null ? largestVideoFiles.length : 0));


    Filtros.ModifiedLast24HoursFilter modifiedFilter = new Filtros.ModifiedLast24HoursFilter();
    File[] modifiedFiles = modifiedFilter.filterModifiedLast24Hours(directory);
    System.out.println("Archivos modificados en las ultimas 24 Horas: " + (modifiedFiles != null ? modifiedFiles.length : 0));


    File[] largeFiles = Filtros.SizeFileFilter.filterBySize(directory, "grande");
    System.out.println("Filtrado por Tamaño: " + (largeFiles != null ? largeFiles.length : 0));
}







}







