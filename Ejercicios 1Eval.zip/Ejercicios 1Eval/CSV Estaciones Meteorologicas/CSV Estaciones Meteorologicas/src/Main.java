import java.io.IOException;
import java.util.List;

/**
 * Clase principal que ejecuta la simulación.
 */
public class Main {
    public static void main(String[] args) throws IOException {
        EstacionMeteorologica estacion1 = new EstacionMeteorologica("001", "Asturias", "Oviedo");
        estacion1.generarDatosAleatorios(100);

        List<RegistroMeteorologico> registros = estacion1.buscarRegistrosPorAnio("001", 2024);
        System.out.println("Temperatura Promedio: " + estacion1.temperaturaPromedio(registros));
        System.out.println("Temperatura Maxima: " + estacion1.temperaturaMaxima(registros));
        System.out.println("Temperatura Minima: " + estacion1.temperaturaMinima(registros));
    }
}