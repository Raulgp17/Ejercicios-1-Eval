import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
/**
 * Clase que representa una estación meteorológica.
 */
class EstacionMeteorologica {
    String id, localidad, ubicacion;
    List<RegistroMeteorologico> registros = new ArrayList<>();

    /**
     * Constructor de la estación.
     * @param id ID único de la estación.
     * @param localidad Nombre de la localidad.
     * @param ubicacion Descripción de la ubicación.
     */
    EstacionMeteorologica(String id, String localidad, String ubicacion) {
        this.id = id;
        this.localidad = localidad;
        this.ubicacion = ubicacion;
    }

    /**
     * Agrega un registro meteorológico a la estación.
     * @param registro Objeto RegistroMeteorologico a agregar.
     */
    void agregarRegistro(RegistroMeteorologico registro) {
        registros.add(registro);
    }

    /**
     * Genera datos aleatorios y los guarda en un archivo CSV.
     * @param cantidad Cantidad de registros a generar.
     * @throws IOException Si ocurre un error al escribir el archivo.
     */
    void generarDatosAleatorios(int cantidad) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(id + ".csv"))) {
            writer.write("ID,Hora,Dia,Mes,Anio,Temperatura,Humedad,Presion,Velocidad,Direccion");
            writer.newLine();
            Random rand = new Random();
            for (int i = 0; i < cantidad; i++) {
                int hora = rand.nextInt(24);
                int dia = rand.nextInt(28) + 1;
                int mes = rand.nextInt(12) + 1;
                int anio = 2024;
                float temperatura = rand.nextFloat() * 40;
                float humedad = rand.nextFloat() * 100;
                float presion = 950 + rand.nextFloat() * 100;
                float velocidad = rand.nextFloat() * 30;
                float direccion = rand.nextFloat() * 360;
                RegistroMeteorologico registro = new RegistroMeteorologico(id, hora, dia, mes, anio, temperatura, humedad, presion, velocidad, direccion);
                agregarRegistro(registro);
                writer.write(String.join(",",
                        id, String.valueOf(hora), String.valueOf(dia), String.valueOf(mes), String.valueOf(anio),
                        String.valueOf(temperatura), String.valueOf(humedad), String.valueOf(presion),
                        String.valueOf(velocidad), String.valueOf(direccion)));
                writer.newLine();
            }
        }
    }

    /**
     * Busca registros en un archivo CSV por ID de estación y año.
     * @param idEstacion ID de la estación.
     * @param anio Año a filtrar.
     * @return Lista de registros encontrados.
     * @throws IOException Si ocurre un error al leer el archivo.
     */
    List<RegistroMeteorologico> buscarRegistrosPorAnio(String idEstacion, int anio) throws IOException {
        List<RegistroMeteorologico> resultados = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(idEstacion + ".csv"))) {
            String linea;
            reader.readLine(); // saltar cabecera
            while ((linea = reader.readLine()) != null) {
                String[] datos = linea.split(",");
                if (datos.length == 10 && Integer.parseInt(datos[4]) == anio) {
                    resultados.add(new RegistroMeteorologico(
                            datos[0], Integer.parseInt(datos[1]), Integer.parseInt(datos[2]),
                            Integer.parseInt(datos[3]), Integer.parseInt(datos[4]),
                            Float.parseFloat(datos[5]), Float.parseFloat(datos[6]),
                            Float.parseFloat(datos[7]), Float.parseFloat(datos[8]),
                            Float.parseFloat(datos[9])));
                }
            }
        }
        return resultados;
    }

    /**
     * Calcula la temperatura promedio de una lista de registros.
     * @param registros Lista de registros.
     * @return Temperatura promedio.
     */
    float temperaturaPromedio(List<RegistroMeteorologico> registros) {
        return (float) registros.stream().mapToDouble(r -> r.temperatura).average().orElse(0);
    }

    /**
     * Calcula la temperatura máxima de una lista de registros.
     * @param registros Lista de registros.
     * @return Temperatura máxima.
     */
    float temperaturaMaxima(List<RegistroMeteorologico> registros) {
        return (float) registros.stream().mapToDouble(r -> r.temperatura).max().orElse(Float.MIN_VALUE);
    }

    /**
     * Calcula la temperatura mínima de una lista de registros.
     * @param registros Lista de registros.
     * @return Temperatura mínima.
     */
    float temperaturaMinima(List<RegistroMeteorologico> registros) {
        return (float) registros.stream().mapToDouble(r -> r.temperatura).min().orElse(Float.MAX_VALUE);
    }

    /**
     * Devuelve el ID de la estación con la temperatura más alta registrada.
     * @param estaciones Lista de estaciones.
     * @return ID de la estación con la temperatura máxima.
     */
    static String estacionTemperaturaMaxima(List<EstacionMeteorologica> estaciones) {
        return estaciones.stream().flatMap(e -> e.registros.stream())
                .max(Comparator.comparingDouble(r -> r.temperatura))
                .map(r -> r.idEstacion).orElse(null);
    }

    /**
     * Calcula la temperatura media de una localidad en un mes y año.
     * @param estaciones Lista de estaciones.
     * @param localidad Localidad a consultar.
     * @param mes Mes (1-12).
     * @param anio Año.
     * @return Temperatura media.
     */
    static float temperaturaMediaMensual(List<EstacionMeteorologica> estaciones, String localidad, int mes, int anio) {
        List<RegistroMeteorologico> registros = estaciones.stream()
                .filter(e -> e.localidad.equalsIgnoreCase(localidad))
                .flatMap(e -> e.registros.stream())
                .filter(r -> r.mes == mes && r.anio == anio)
                .collect(Collectors.toList());
        return (float) registros.stream().mapToDouble(r -> r.temperatura).average().orElse(0);
    }
}