import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

/**
 * Clase que representa un registro meteorológico de una estación.
 */
class RegistroMeteorologico {
    String idEstacion;
    int hora, dia, mes, anio;
    float temperatura, humedad, presion, velocidad, direccion;

    /**
     * Constructor para inicializar un registro meteorológico.
     * @param idEstacion ID de la estación.
     * @param hora Hora del día (0-23).
     * @param dia Día del mes.
     * @param mes Mes del año.
     * @param anio Año del registro.
     * @param temperatura Temperatura en grados Celsius.
     * @param humedad Humedad relativa en %.
     * @param presion Presión atmosférica en hPa.
     * @param velocidad Velocidad del viento en m/s.
     * @param direccion Dirección del viento en grados.
     */
    RegistroMeteorologico(String idEstacion, int hora, int dia, int mes, int anio,
                          float temperatura, float humedad, float presion, float velocidad, float direccion) {
        this.idEstacion = idEstacion;
        this.hora = hora;
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
        this.temperatura = temperatura;
        this.humedad = humedad;
        this.presion = presion;
        this.velocidad = velocidad;
        this.direccion = direccion;
    }
}
