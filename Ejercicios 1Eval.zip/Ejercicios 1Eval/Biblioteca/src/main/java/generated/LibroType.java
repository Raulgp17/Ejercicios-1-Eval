//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.3.2 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2025.06.10 a las 02:34:41 AM CEST 
//


package generated;

import java.math.BigInteger;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para libroType complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="libroType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ISBN" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="titulo" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="autor" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="editorial" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="numeroPaginas" type="{http://www.w3.org/2001/XMLSchema}integer"/&gt;
 *         &lt;element name="fechaPublicacion" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *         &lt;element name="totalEjemplares" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
 *         &lt;element name="totalEjemplaresDisponibles" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "libroType", propOrder = {
    "isbn",
    "titulo",
    "autor",
    "editorial",
    "numeroPaginas",
    "fechaPublicacion",
    "totalEjemplares",
    "totalEjemplaresDisponibles"
})
public class LibroType {

    @XmlElement(name = "ISBN", required = true)
    protected String isbn;
    @XmlElement(required = true)
    protected String titulo;
    @XmlElement(required = true)
    protected String autor;
    @XmlElement(required = true)
    protected String editorial;
    @XmlElement(required = true)
    protected BigInteger numeroPaginas;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected Date fechaPublicacion;
    @XmlElement(required = true)
    protected Object totalEjemplares;
    @XmlElement(required = true)
    protected Object totalEjemplaresDisponibles;

    /**
     * Obtiene el valor de la propiedad isbn.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISBN() {
        return isbn;
    }

    /**
     * Define el valor de la propiedad isbn.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISBN(String value) {
        this.isbn = value;
    }

    /**
     * Obtiene el valor de la propiedad titulo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * Define el valor de la propiedad titulo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitulo(String value) {
        this.titulo = value;
    }

    /**
     * Obtiene el valor de la propiedad autor.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAutor() {
        return autor;
    }

    /**
     * Define el valor de la propiedad autor.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAutor(String value) {
        this.autor = value;
    }

    /**
     * Obtiene el valor de la propiedad editorial.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEditorial() {
        return editorial;
    }

    /**
     * Define el valor de la propiedad editorial.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEditorial(String value) {
        this.editorial = value;
    }

    /**
     * Obtiene el valor de la propiedad numeroPaginas.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNumeroPaginas() {
        return numeroPaginas;
    }

    /**
     * Define el valor de la propiedad numeroPaginas.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNumeroPaginas(BigInteger value) {
        this.numeroPaginas = value;
    }

    /**
     * Obtiene el valor de la propiedad fechaPublicacion.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public Date getFechaPublicacion() {
        return fechaPublicacion;
    }

    /**
     * Define el valor de la propiedad fechaPublicacion.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFechaPublicacion(Date value) {
        this.fechaPublicacion = value;
    }

    /**
     * Obtiene el valor de la propiedad totalEjemplares.
     * 
     * @return
     *     possible object is
     *     {@link Object }
     *     
     */
    public Object getTotalEjemplares() {
        return totalEjemplares;
    }

    /**
     * Define el valor de la propiedad totalEjemplares.
     * 
     * @param value
     *     allowed object is
     *     {@link Object }
     *     
     */
    public void setTotalEjemplares(Object value) {
        this.totalEjemplares = value;
    }

    /**
     * Obtiene el valor de la propiedad totalEjemplaresDisponibles.
     * 
     * @return
     *     possible object is
     *     {@link Object }
     *     
     */
    public Object getTotalEjemplaresDisponibles() {
        return totalEjemplaresDisponibles;
    }

    /**
     * Define el valor de la propiedad totalEjemplaresDisponibles.
     * 
     * @param value
     *     allowed object is
     *     {@link Object }
     *     
     */
    public void setTotalEjemplaresDisponibles(Object value) {
        this.totalEjemplaresDisponibles = value;
    }

}
