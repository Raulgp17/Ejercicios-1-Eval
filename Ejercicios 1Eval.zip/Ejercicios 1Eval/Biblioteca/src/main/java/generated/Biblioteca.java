//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.3.2 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2025.06.10 a las 02:34:41 AM CEST 
//


package generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="libros"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence maxOccurs="unbounded"&gt;
 *                   &lt;element name="libro" type="{}libroType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="socios"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence maxOccurs="unbounded"&gt;
 *                   &lt;element name="socio" type="{}socioType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="prestamos"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence maxOccurs="unbounded"&gt;
 *                   &lt;element name="prestamo" type="{}prestamoType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="parametros"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="diasPrestamo" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
 *                   &lt;element name="totalSocios" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
 *                   &lt;element name="totalLibros" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "libros",
    "socios",
    "prestamos",
    "parametros"
})
@XmlRootElement(name = "biblioteca")
public class Biblioteca {

    @XmlElement(required = true)
    protected Biblioteca.Libros libros;
    @XmlElement(required = true)
    protected Biblioteca.Socios socios;
    @XmlElement(required = true)
    protected Biblioteca.Prestamos prestamos;
    @XmlElement(required = true)
    protected Biblioteca.Parametros parametros;

    /**
     * Obtiene el valor de la propiedad libros.
     * 
     * @return
     *     possible object is
     *     {@link Biblioteca.Libros }
     *     
     */
    public Biblioteca.Libros getLibros() {
        return libros;
    }

    /**
     * Define el valor de la propiedad libros.
     * 
     * @param value
     *     allowed object is
     *     {@link Biblioteca.Libros }
     *     
     */
    public void setLibros(Biblioteca.Libros value) {
        this.libros = value;
    }

    /**
     * Obtiene el valor de la propiedad socios.
     * 
     * @return
     *     possible object is
     *     {@link Biblioteca.Socios }
     *     
     */
    public Biblioteca.Socios getSocios() {
        return socios;
    }

    /**
     * Define el valor de la propiedad socios.
     * 
     * @param value
     *     allowed object is
     *     {@link Biblioteca.Socios }
     *     
     */
    public void setSocios(Biblioteca.Socios value) {
        this.socios = value;
    }

    /**
     * Obtiene el valor de la propiedad prestamos.
     * 
     * @return
     *     possible object is
     *     {@link Biblioteca.Prestamos }
     *     
     */
    public Biblioteca.Prestamos getPrestamos() {
        return prestamos;
    }

    /**
     * Define el valor de la propiedad prestamos.
     * 
     * @param value
     *     allowed object is
     *     {@link Biblioteca.Prestamos }
     *     
     */
    public void setPrestamos(Biblioteca.Prestamos value) {
        this.prestamos = value;
    }

    /**
     * Obtiene el valor de la propiedad parametros.
     * 
     * @return
     *     possible object is
     *     {@link Biblioteca.Parametros }
     *     
     */
    public Biblioteca.Parametros getParametros() {
        return parametros;
    }

    /**
     * Define el valor de la propiedad parametros.
     * 
     * @param value
     *     allowed object is
     *     {@link Biblioteca.Parametros }
     *     
     */
    public void setParametros(Biblioteca.Parametros value) {
        this.parametros = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence maxOccurs="unbounded"&gt;
     *         &lt;element name="libro" type="{}libroType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "libro"
    })
    public static class Libros {

        @XmlElement(required = true)
        protected List<LibroType> libro;

        /**
         * Gets the value of the libro property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the libro property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getLibro().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link LibroType }
         * 
         * 
         */
        public List<LibroType> getLibro() {
            if (libro == null) {
                libro = new ArrayList<LibroType>();
            }
            return this.libro;
        }

    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="diasPrestamo" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
     *         &lt;element name="totalSocios" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
     *         &lt;element name="totalLibros" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "diasPrestamo",
        "totalSocios",
        "totalLibros"
    })
    public static class Parametros {

        @XmlElement(required = true)
        protected Object diasPrestamo;
        @XmlElement(required = true)
        protected Object totalSocios;
        @XmlElement(required = true)
        protected Object totalLibros;

        /**
         * Obtiene el valor de la propiedad diasPrestamo.
         * 
         * @return
         *     possible object is
         *     {@link Object }
         *     
         */
        public Object getDiasPrestamo() {
            return diasPrestamo;
        }

        /**
         * Define el valor de la propiedad diasPrestamo.
         * 
         * @param value
         *     allowed object is
         *     {@link Object }
         *     
         */
        public void setDiasPrestamo(Object value) {
            this.diasPrestamo = value;
        }

        /**
         * Obtiene el valor de la propiedad totalSocios.
         * 
         * @return
         *     possible object is
         *     {@link Object }
         *     
         */
        public Object getTotalSocios() {
            return totalSocios;
        }

        /**
         * Define el valor de la propiedad totalSocios.
         * 
         * @param value
         *     allowed object is
         *     {@link Object }
         *     
         */
        public void setTotalSocios(Object value) {
            this.totalSocios = value;
        }

        /**
         * Obtiene el valor de la propiedad totalLibros.
         * 
         * @return
         *     possible object is
         *     {@link Object }
         *     
         */
        public Object getTotalLibros() {
            return totalLibros;
        }

        /**
         * Define el valor de la propiedad totalLibros.
         * 
         * @param value
         *     allowed object is
         *     {@link Object }
         *     
         */
        public void setTotalLibros(Object value) {
            this.totalLibros = value;
        }

    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence maxOccurs="unbounded"&gt;
     *         &lt;element name="prestamo" type="{}prestamoType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "prestamo"
    })
    public static class Prestamos {

        @XmlElement(required = true)
        protected List<PrestamoType> prestamo;

        /**
         * Gets the value of the prestamo property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the prestamo property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPrestamo().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link PrestamoType }
         * 
         * 
         */
        public List<PrestamoType> getPrestamo() {
            if (prestamo == null) {
                prestamo = new ArrayList<PrestamoType>();
            }
            return this.prestamo;
        }

    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence maxOccurs="unbounded"&gt;
     *         &lt;element name="socio" type="{}socioType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "socio"
    })
    public static class Socios {

        @XmlElement(required = true)
        protected List<SocioType> socio;

        /**
         * Gets the value of the socio property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the socio property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getSocio().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link SocioType }
         * 
         * 
         */
        public List<SocioType> getSocio() {
            if (socio == null) {
                socio = new ArrayList<SocioType>();
            }
            return this.socio;
        }

    }

}
