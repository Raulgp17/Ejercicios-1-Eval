//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.3.2 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2025.06.10 a las 02:34:41 AM CEST 
//


package generated;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para socioType complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="socioType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="codigoSocio" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="nombreSocio" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="apellidoSocio" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="2"/&gt;
 *         &lt;element name="telefono" type="{http://www.w3.org/2001/XMLSchema}integer"/&gt;
 *         &lt;element name="direccion"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="calle" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                   &lt;element name="ciudad" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                   &lt;element name="provincia" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                   &lt;element name="codigoPostal" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="librosPrestados"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence maxOccurs="5"&gt;
 *                   &lt;element name="prestamo"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="ISBN" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
 *                             &lt;element name="titulo" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
 *                             &lt;element name="fechaPrestamo" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "socioType", propOrder = {
    "codigoSocio",
    "nombreSocio",
    "apellidoSocio",
    "telefono",
    "direccion",
    "librosPrestados"
})
public class SocioType {

    @XmlElement(required = true)
    protected String codigoSocio;
    @XmlElement(required = true)
    protected String nombreSocio;
    @XmlElement(required = true)
    protected List<String> apellidoSocio;
    @XmlElement(required = true)
    protected BigInteger telefono;
    @XmlElement(required = true)
    protected SocioType.Direccion direccion;
    @XmlElement(required = true)
    protected SocioType.LibrosPrestados librosPrestados;

    /**
     * Obtiene el valor de la propiedad codigoSocio.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoSocio() {
        return codigoSocio;
    }

    /**
     * Define el valor de la propiedad codigoSocio.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoSocio(String value) {
        this.codigoSocio = value;
    }

    /**
     * Obtiene el valor de la propiedad nombreSocio.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNombreSocio() {
        return nombreSocio;
    }

    /**
     * Define el valor de la propiedad nombreSocio.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNombreSocio(String value) {
        this.nombreSocio = value;
    }

    /**
     * Gets the value of the apellidoSocio property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the apellidoSocio property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getApellidoSocio().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getApellidoSocio() {
        if (apellidoSocio == null) {
            apellidoSocio = new ArrayList<String>();
        }
        return this.apellidoSocio;
    }

    /**
     * Obtiene el valor de la propiedad telefono.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getTelefono() {
        return telefono;
    }

    /**
     * Define el valor de la propiedad telefono.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setTelefono(BigInteger value) {
        this.telefono = value;
    }

    /**
     * Obtiene el valor de la propiedad direccion.
     * 
     * @return
     *     possible object is
     *     {@link SocioType.Direccion }
     *     
     */
    public SocioType.Direccion getDireccion() {
        return direccion;
    }

    /**
     * Define el valor de la propiedad direccion.
     * 
     * @param value
     *     allowed object is
     *     {@link SocioType.Direccion }
     *     
     */
    public void setDireccion(SocioType.Direccion value) {
        this.direccion = value;
    }

    /**
     * Obtiene el valor de la propiedad librosPrestados.
     * 
     * @return
     *     possible object is
     *     {@link SocioType.LibrosPrestados }
     *     
     */
    public SocioType.LibrosPrestados getLibrosPrestados() {
        return librosPrestados;
    }

    /**
     * Define el valor de la propiedad librosPrestados.
     * 
     * @param value
     *     allowed object is
     *     {@link SocioType.LibrosPrestados }
     *     
     */
    public void setLibrosPrestados(SocioType.LibrosPrestados value) {
        this.librosPrestados = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="calle" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *         &lt;element name="ciudad" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *         &lt;element name="provincia" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *         &lt;element name="codigoPostal" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "calle",
        "ciudad",
        "provincia",
        "codigoPostal"
    })
    public static class Direccion {

        @XmlElement(required = true)
        protected String calle;
        @XmlElement(required = true)
        protected String ciudad;
        @XmlElement(required = true)
        protected String provincia;
        @XmlElement(required = true)
        protected String codigoPostal;

        /**
         * Obtiene el valor de la propiedad calle.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCalle() {
            return calle;
        }

        /**
         * Define el valor de la propiedad calle.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCalle(String value) {
            this.calle = value;
        }

        /**
         * Obtiene el valor de la propiedad ciudad.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCiudad() {
            return ciudad;
        }

        /**
         * Define el valor de la propiedad ciudad.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCiudad(String value) {
            this.ciudad = value;
        }

        /**
         * Obtiene el valor de la propiedad provincia.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getProvincia() {
            return provincia;
        }

        /**
         * Define el valor de la propiedad provincia.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setProvincia(String value) {
            this.provincia = value;
        }

        /**
         * Obtiene el valor de la propiedad codigoPostal.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCodigoPostal() {
            return codigoPostal;
        }

        /**
         * Define el valor de la propiedad codigoPostal.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCodigoPostal(String value) {
            this.codigoPostal = value;
        }

    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence maxOccurs="5"&gt;
     *         &lt;element name="prestamo"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="ISBN" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
     *                   &lt;element name="titulo" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
     *                   &lt;element name="fechaPrestamo" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "prestamo"
    })
    public static class LibrosPrestados {

        @XmlElement(required = true)
        protected List<SocioType.LibrosPrestados.Prestamo> prestamo;

        /**
         * Gets the value of the prestamo property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the prestamo property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPrestamo().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link SocioType.LibrosPrestados.Prestamo }
         * 
         * 
         */
        public List<SocioType.LibrosPrestados.Prestamo> getPrestamo() {
            if (prestamo == null) {
                prestamo = new ArrayList<SocioType.LibrosPrestados.Prestamo>();
            }
            return this.prestamo;
        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="ISBN" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
         *         &lt;element name="titulo" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
         *         &lt;element name="fechaPrestamo" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "isbn",
            "titulo",
            "fechaPrestamo"
        })
        public static class Prestamo {

            @XmlElement(name = "ISBN", required = true)
            protected Object isbn;
            @XmlElement(required = true)
            protected Object titulo;
            @XmlElement(required = true)
            protected Object fechaPrestamo;

            /**
             * Obtiene el valor de la propiedad isbn.
             * 
             * @return
             *     possible object is
             *     {@link Object }
             *     
             */
            public Object getISBN() {
                return isbn;
            }

            /**
             * Define el valor de la propiedad isbn.
             * 
             * @param value
             *     allowed object is
             *     {@link Object }
             *     
             */
            public void setISBN(Object value) {
                this.isbn = value;
            }

            /**
             * Obtiene el valor de la propiedad titulo.
             * 
             * @return
             *     possible object is
             *     {@link Object }
             *     
             */
            public Object getTitulo() {
                return titulo;
            }

            /**
             * Define el valor de la propiedad titulo.
             * 
             * @param value
             *     allowed object is
             *     {@link Object }
             *     
             */
            public void setTitulo(Object value) {
                this.titulo = value;
            }

            /**
             * Obtiene el valor de la propiedad fechaPrestamo.
             * 
             * @return
             *     possible object is
             *     {@link Object }
             *     
             */
            public Object getFechaPrestamo() {
                return fechaPrestamo;
            }

            /**
             * Define el valor de la propiedad fechaPrestamo.
             * 
             * @param value
             *     allowed object is
             *     {@link Object }
             *     
             */
            public void setFechaPrestamo(Object value) {
                this.fechaPrestamo = value;
            }

        }

    }

}
