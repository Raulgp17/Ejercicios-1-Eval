package com.biblioteca.sevicio;

import com.biblioteca.sevicio.BibliotecaManager;
import generated.*;

import javax.xml.bind.*;
import java.io.File;
import java.math.BigInteger;
import java.util.*;
import java.util.stream.Collectors;


public class BibliotecaServiceImpl implements BibliotecaManager {

    private Biblioteca biblioteca;

    public BibliotecaServiceImpl() {
        this.biblioteca = new Biblioteca();
        if (biblioteca.getSocios() == null) {
            biblioteca.setSocios(new Biblioteca.Socios());
        }

        if (biblioteca.getLibros() == null) {
            biblioteca.setLibros(new Biblioteca.Libros());
        }

        if (biblioteca.getPrestamos() == null) {
            biblioteca.setPrestamos(new Biblioteca.Prestamos());
        }


    }

//metodo que uso para el cast de getejemplaresDisponibles
    public static int getAsInt(Object value, int defaultValue) {
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        return defaultValue;
    }


    // 2. Operaciones con XML
    @Override
    public Biblioteca importarDesdeXML(String rutaArchivo) throws Exception {
        JAXBContext context = JAXBContext.newInstance(Biblioteca.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();
        this.biblioteca = (Biblioteca) unmarshaller.unmarshal(new File(rutaArchivo));
        return biblioteca;
    }

    @Override
    public void exportarAXML(Biblioteca biblioteca, String rutaArchivo) throws Exception {
        JAXBContext context = JAXBContext.newInstance(Biblioteca.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshaller.marshal(biblioteca, new File(rutaArchivo));
    }

    // 3. Registro Socios y Libros
    @Override
    public void registrarSocio(SocioType nuevoSocio) throws Exception {
        boolean existe = biblioteca.getSocios().getSocio().stream()
                .anyMatch(s -> s.getCodigoSocio().equals(nuevoSocio.getCodigoSocio()));
        if (existe) throw new Exception("El socio ya existe con código: " + nuevoSocio.getCodigoSocio());
        biblioteca.getSocios().getSocio().add(nuevoSocio);
    }

    @Override
    public void añadirLibro(LibroType nuevoLibro) throws Exception {
        boolean existe = biblioteca.getLibros().getLibro().stream()
                .anyMatch(l -> l.getISBN().equals(nuevoLibro.getISBN()));
        if (existe) throw new Exception("El libro ya existe con ISBN: " + nuevoLibro.getISBN());
        // Set disponibilidad igual a total
        nuevoLibro.setTotalEjemplaresDisponibles(nuevoLibro.getTotalEjemplares());
        biblioteca.getLibros().getLibro().add(nuevoLibro);
    }

    // 4. Préstamos
    @Override
    public void realizarPrestamo(String codigoSocio, String isbnLibro) throws Exception {
        SocioType socio = biblioteca.getSocios().getSocio().stream()
                .filter(s -> s.getCodigoSocio().equals(codigoSocio))
                .findFirst().orElseThrow(() -> new Exception("Socio no encontrado"));

        LibroType libro = biblioteca.getLibros().getLibro().stream()
                .filter(l -> l.getISBN().equals(isbnLibro))
                .findFirst().orElseThrow(() -> new Exception("Libro no encontrado"));

        if (getAsInt(libro.getTotalEjemplaresDisponibles(), 0) <= 0)
            throw new Exception("No hay ejemplares disponibles para préstamo");

        // Reducir stock disponible
        libro.setTotalEjemplaresDisponibles(
                BigInteger.valueOf(getAsInt(libro.getTotalEjemplaresDisponibles(), 0) - 1));

        // Crear préstamo
        PrestamoType prestamo = new PrestamoType();
        prestamo.setCodigoSocio(codigoSocio);
        prestamo.setISBN(isbnLibro);
        prestamo.setFechaPrestamo(new Date());

        biblioteca.getPrestamos().getPrestamo().add(prestamo);
    }

    @Override
    public void devolverLibro(String codigoSocio, String isbnLibro) throws Exception {
        // Buscar préstamo
        Optional<PrestamoType> prestamoOpt = biblioteca.getPrestamos().getPrestamo().stream()
                .filter(p -> p.getCodigoSocio().equals(codigoSocio) && p.getISBN().equals(isbnLibro))
                .findFirst();

        if (prestamoOpt.isEmpty()) throw new Exception("Préstamo no encontrado");

        PrestamoType prestamo = prestamoOpt.get();

        // Eliminar préstamo
        biblioteca.getPrestamos().getPrestamo().remove(prestamo);

        // Aumentar stock disponible
        LibroType libro = biblioteca.getLibros().getLibro().stream()
                .filter(l -> l.getISBN().equals(isbnLibro))
                .findFirst().orElseThrow(() -> new Exception("Libro no encontrado"));

        libro.setTotalEjemplaresDisponibles(
                BigInteger.valueOf(getAsInt(libro.getTotalEjemplaresDisponibles(), 0) + 1));
    }

    // 5. Modificación y consultas
    @Override
    public void modificarDatosSocio(String codigoSocio, String nuevoNombre, List<String> nuevosApellidos, int nuevoTelefono) throws Exception {
        SocioType socio = biblioteca.getSocios().getSocio().stream()
                .filter(s -> s.getCodigoSocio().equals(codigoSocio))
                .findFirst().orElseThrow(() -> new Exception("Socio no encontrado"));

        socio.setNombreSocio(nuevoNombre);
        socio.getApellidoSocio().clear();
        socio.getApellidoSocio().addAll(nuevosApellidos);
        socio.setTelefono(BigInteger.valueOf(nuevoTelefono));
    }

    @Override
    public Optional<List<PrestamoType>> consultarPrestamosPorNombreYApellido(String nombre, List<String> apellidos) {
        List<SocioType> socios = biblioteca.getSocios().getSocio().stream()
                .filter(s -> s.getNombreSocio().equalsIgnoreCase(nombre)
                        && s.getApellidoSocio().containsAll(apellidos))
                .collect(Collectors.toList());

        if (socios.isEmpty()) return Optional.empty();

        List<PrestamoType> prestamos = new ArrayList<>();
        for (SocioType socio : socios) {
            prestamos.addAll(biblioteca.getPrestamos().getPrestamo().stream()
                    .filter(p -> p.getCodigoSocio().equals(socio.getCodigoSocio()))
                    .collect(Collectors.toList()));
        }
        return Optional.of(prestamos);
    }

    // 6. Funcionalidades adicionales
    @Override
    public Map<SocioType, List<PrestamoType>> obtenerSociosConPrestamos() {
        Map<String, SocioType> codSocioMap = biblioteca.getSocios().getSocio().stream()
                .collect(Collectors.toMap(SocioType::getCodigoSocio, s -> s));
        Map<SocioType, List<PrestamoType>> resultado = new HashMap<>();
        for (PrestamoType prestamo : biblioteca.getPrestamos().getPrestamo()) {
            SocioType socio = codSocioMap.get(prestamo.getCodigoSocio());
            resultado.computeIfAbsent(socio, k -> new ArrayList<>()).add(prestamo);
        }
        return resultado;
    }

    @Override
    public Map<String, List<SocioType>> organizarSociosPorProvincia() {
        // Asumimos provincia según prefijo de teléfono (3 primeros dígitos)
        Map<String, List<SocioType>> mapa = new HashMap<>();
        for (SocioType socio : biblioteca.getSocios().getSocio()) {
            String telefonoStr = socio.getTelefono().toString();
            String provincia = telefonoStr.length() >= 3 ? telefonoStr.substring(0, 3) : "Desconocido";
            mapa.computeIfAbsent(provincia, k -> new ArrayList<>()).add(socio);
        }
        return mapa;
    }

    @Override
    public List<SocioType> obtenerSociosConMasPrestamos() {
        Map<SocioType, Long> prestamosPorSocio = obtenerSociosConPrestamos().entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey, e -> (long) e.getValue().size()));

        long maxPrestamos = prestamosPorSocio.values().stream()
                .max(Long::compareTo).orElse(0L);

        return prestamosPorSocio.entrySet().stream()
                .filter(e -> e.getValue() == maxPrestamos)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
    }

    @Override
    public int calcularPesoTotalLibrosEnStock() {
        // Cada página pesa 3 gramos
        int totalGramos = 0;
        for (LibroType libro : biblioteca.getLibros().getLibro()) {
            int paginas = libro.getNumeroPaginas().intValue();
            int disponibles = getAsInt(libro.getTotalEjemplaresDisponibles(), 0);
            totalGramos += paginas * 3 * disponibles;
        }
        return totalGramos;
    }

    @Override
    public List<List<LibroType>> repartirLibrosEnCajasPorCantidad(int cantidadPorCaja) {
        List<List<LibroType>> cajas = new ArrayList<>();
        List<LibroType> libros = new ArrayList<>(biblioteca.getLibros().getLibro());

        int totalLibros = libros.size();
        for (int i = 0; i < totalLibros; i += cantidadPorCaja) {
            cajas.add(libros.subList(i, Math.min(i + cantidadPorCaja, totalLibros)));
        }
        return cajas;
    }

    @Override
    public List<List<LibroType>> repartirLibrosEnCajasPorPeso(int pesoMaximoPorCajaGramos) {
        List<List<LibroType>> cajas = new ArrayList<>();
        List<LibroType> libros = new ArrayList<>(biblioteca.getLibros().getLibro());

        List<LibroType> cajaActual = new ArrayList<>();
        int pesoActual = 0;

        for (LibroType libro : libros) {
            int pesoLibro = libro.getNumeroPaginas().intValue() * 3;
            if (pesoActual + pesoLibro > pesoMaximoPorCajaGramos && !cajaActual.isEmpty()) {
                cajas.add(new ArrayList<>(cajaActual));
                cajaActual.clear();
                pesoActual = 0;
            }
            cajaActual.add(libro);
            pesoActual += pesoLibro;
        }

        if (!cajaActual.isEmpty()) {
            cajas.add(cajaActual);
        }

        return cajas;
    }
}
