package com.biblioteca.app;

import com.biblioteca.sevicio.BibliotecaManager;
import com.biblioteca.sevicio.BibliotecaServiceImpl;
import generated.*;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

public class AdministrarBiblioteca {

    public static void main(String[] args) {
        try {
            BibliotecaManager manager = new BibliotecaServiceImpl();

            // 1. Registrar Socio
            SocioType socio = new SocioType();
            socio.setCodigoSocio("S001");
            socio.setNombreSocio("Juan");
            socio.getApellidoSocio().addAll(Arrays.asList("Pérez", "Gómez"));
            socio.setTelefono(BigInteger.valueOf(987654321));
            manager.registrarSocio(socio);
            System.out.println("Socio registrado.");

            // 2. Añadir Libros
            LibroType libro = new LibroType();
            libro.setISBN("ISBN001");
            libro.setTitulo("Java Básico");
            libro.setAutor("Autor Ejemplo");
            libro.setEditorial("Editorial XYZ");
            libro.setNumeroPaginas(BigInteger.valueOf(350));
            libro.setFechaPublicacion(new Date());
            libro.setTotalEjemplares(BigInteger.valueOf(5));
            libro.setTotalEjemplaresDisponibles(BigInteger.valueOf(5));
            manager.añadirLibro(libro);
            System.out.println("Libro añadido.");

            // 3. Realizar un préstamo
            manager.realizarPrestamo("S001", "ISBN001");
            System.out.println("Préstamo realizado.");

            // 4. Consultar préstamos por nombre y apellidos
            Optional<List<PrestamoType>> prestamos = manager.consultarPrestamosPorNombreYApellido("Juan", Arrays.asList("Pérez", "Gómez"));
            prestamos.ifPresentOrElse(
                    list -> System.out.println("Préstamos encontrados: " + list.size()),
                    () -> System.out.println("No se encontraron préstamos para el socio.")
            );

            // 5. Devolver el libro
            manager.devolverLibro("S001", "ISBN001");
            System.out.println("Libro devuelto.");

            // 6. Socios con más préstamos (debería estar vacío ahora)
            List<SocioType> topSocios = manager.obtenerSociosConMasPrestamos();
            System.out.println("Socios con más préstamos: " + topSocios.size());

            // 7. Exportar biblioteca a XML
            manager.exportarAXML(manager.importarDesdeXML("src/main/resources/BIBLIOTECA.xml"), "BIBLIOTECA.xml");
            System.out.println("Datos exportados a biblioteca.xml.");

        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
