package com.biblioteca.sevicio;

import generated.*;
import java.util.*;

public interface BibliotecaManager {

    // Importar y exportar XML
    Biblioteca importarDesdeXML(String rutaArchivo) throws Exception;
    void exportarAXML(Biblioteca biblioteca, String rutaArchivo) throws Exception;

    // Registro de socios y libros
    void registrarSocio(SocioType nuevoSocio) throws Exception;
    void añadirLibro(LibroType nuevoLibro) throws Exception;

    // Préstamos
    void realizarPrestamo(String codigoSocio, String isbnLibro) throws Exception;
    void devolverLibro(String codigoSocio, String isbnLibro) throws Exception;

    // Modificaciones y consultas
    void modificarDatosSocio(String codigoSocio, String nuevoNombre, List<String> nuevosApellidos, int nuevoTelefono) throws Exception;
    Optional<List<PrestamoType>> consultarPrestamosPorNombreYApellido(String nombre, List<String> apellidos);

    // Funcionalidades adicionales
    Map<SocioType, List<PrestamoType>> obtenerSociosConPrestamos();
    Map<String, List<SocioType>> organizarSociosPorProvincia();
    List<SocioType> obtenerSociosConMasPrestamos();
    int calcularPesoTotalLibrosEnStock();
    List<List<LibroType>> repartirLibrosEnCajasPorCantidad(int cantidadPorCaja);
    List<List<LibroType>> repartirLibrosEnCajasPorPeso(int pesoMaximoPorCajaGramos);
}
