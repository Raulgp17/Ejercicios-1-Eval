import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        try {
            String filePath = "CP/el_quijote.txt";

            TextAnalysisModel model = new TextAnalysisModel(filePath);
            TextAnalysisView view = new TextAnalysisView();
            TextAnalysisController controller = new TextAnalysisController(model, view);

            controller.start();
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}
