import java.io.IOException;
import java.util.Scanner;

public class TextAnalysisController {

    private TextAnalysisModel model;
    private TextAnalysisView view;

    public TextAnalysisController(TextAnalysisModel model, TextAnalysisView view) {
        this.model = model;
        this.view = view;
    }

    // Método para ejecutar el análisis
    public void start() {
        try (Scanner scanner = new Scanner(System.in)) {
            view.showLineCount(model.countLines());
            view.showTotalLetters(model.totalLetters());

            System.out.print("Introduce una palabra para analizar su frecuencia: ");
            String word = scanner.nextLine();
            view.showWordFrequency(word, model.wordFrequency(word));

            view.showWordFrequencyMap(model.wordFrequencyMap());
            view.showWordsByLength(model.wordsByLength());
            view.showWordsByInitialLetter(model.wordsByInitialLetter());
            view.showReadingTimes(model.calculateReadingTime());
        }
    }
}
