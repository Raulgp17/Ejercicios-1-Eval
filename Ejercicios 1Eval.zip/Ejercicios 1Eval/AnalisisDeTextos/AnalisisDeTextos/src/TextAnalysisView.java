import java.util.List;
import java.util.Map;

public class TextAnalysisView {


    public void showLineCount(int count) {
        System.out.println("Número total de líneas: " + count);
    }


    public void showWordFrequency(String word, int frequency) {
        System.out.println("La palabra '" + word + "' aparece " + frequency + " veces.");
    }


    public void showTotalLetters(int count) {
        System.out.println("Número total de letras: " + count);
    }


    public void showWordFrequencyMap(Map<String, Integer> wordMap) {
        System.out.println("Frecuencia de palabras:");
        wordMap.forEach((word, count) -> System.out.println(word + ": " + count));
    }


    public void showWordsByLength(Map<Integer, List<String>> wordsByLength) {
        System.out.println("Palabras clasificadas por longitud:");
        wordsByLength.forEach((length, words) -> System.out.println(length + " letras: " + words));
    }


    public void showWordsByInitialLetter(Map<Character, List<String>> wordsByInitial) {
        System.out.println("Palabras clasificadas por letra inicial:");
        wordsByInitial.forEach((initial, words) -> System.out.println(initial + ": " + words));
    }


    public void showReadingTimes(Map<String, Double> readingTimes) {
        System.out.println("Tiempos de lectura estimados:");
        readingTimes.forEach((level, time) -> System.out.println(level + ": " + String.format("%.2f", time) + " minutos"));
    }
}
