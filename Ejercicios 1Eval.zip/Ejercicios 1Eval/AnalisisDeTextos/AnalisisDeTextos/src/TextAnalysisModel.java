import java.io.*;
import java.util.*;

public class TextAnalysisModel {

    private List<String> lines;

    public TextAnalysisModel(String filePath) throws IOException {
        this.lines = readFile(filePath);
    }

    // Método para leer el archivo y almacenar las líneas en una lista
    private List<String> readFile(String filePath) throws IOException {
        List<String> lines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        }
        return lines;
    }

    // Contar el número de líneas
    public int countLines() {
        return lines.size();
    }

    // Contar la frecuencia de una palabra específica
    public int wordFrequency(String word) {
        int count = 0;
        for (String line : lines) {
            String[] words = line.split("\\W+");
            for (String w : words) {
                if (w.equalsIgnoreCase(word)) {
                    count++;
                }
            }
        }
        return count;
    }

    // Contar el número total de letras
    public int totalLetters() {
        int count = 0;
        for (String line : lines) {
            for (char c : line.toCharArray()) {
                if (Character.isLetter(c)) {
                    count++;
                }
            }
        }
        return count;
    }

    // Mapa de frecuencia de palabras
    public Map<String, Integer> wordFrequencyMap() {
        Map<String, Integer> wordCount = new HashMap<>();
        for (String line : lines) {
            String[] words = line.split("\\W+");
            for (String word : words) {
                if (!word.isEmpty()) {
                    word = word.toLowerCase();
                    wordCount.put(word, wordCount.getOrDefault(word, 0) + 1);
                }
            }
        }
        return wordCount;
    }

    // Clasificación de palabras por longitud
    public Map<Integer, List<String>> wordsByLength() {
        Map<Integer, List<String>> wordsByLength = new HashMap<>();
        for (String line : lines) {
            String[] words = line.split("\\W+");
            for (String word : words) {
                int length = word.length();
                if (length > 0) {
                    wordsByLength.computeIfAbsent(length, k -> new ArrayList<>()).add(word);
                }
            }
        }
        return wordsByLength;
    }

    // Clasificación de palabras por letra inicial
    public Map<Character, List<String>> wordsByInitialLetter() {
        Map<Character, List<String>> wordsByInitialLetter = new HashMap<>();
        for (String line : lines) {
            String[] words = line.split("\\W+");
            for (String word : words) {
                if (!word.isEmpty()) {
                    char initial = Character.toLowerCase(word.charAt(0));
                    wordsByInitialLetter.computeIfAbsent(initial, k -> new ArrayList<>()).add(word);
                }
            }
        }
        return wordsByInitialLetter;
    }

    // Calcular el tiempo de lectura basado en las velocidades dadas
    public Map<String, Double> calculateReadingTime() {
        int totalWords = 0;
        for (String line : lines) {
            totalWords += line.split("\\W+").length;
        }

        Map<String, Double> readingTimes = new HashMap<>();
        readingTimes.put("Lector lento", (double) totalWords / 150);
        readingTimes.put("Lector promedio", (double) totalWords / 250);
        readingTimes.put("Lector rápido", (double) totalWords / 350);
        readingTimes.put("Lector muy rápido", (double) totalWords / 450);

        return readingTimes;
    }
}
