import Logica.OperacionesFicheros;
import Logica.NoEsUnDirectorioNoSePuedeListar;
import Logica.CarpetaVacia;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase principal para probar los métodos de OperacionesFicheros.
 */
public class Main {
    /**
     * Método principal que ejecuta una prueba sencilla de cada método.
     */
    public static void main(String[] args) {
        OperacionesFicheros op = new OperacionesFicheros();
        String rutaPrueba = "C:/Users/Raul/Prueba"; // Cambia por una ruta válida en tu equipo

        // 1. Probar listarFicheros (solo directorios, sin ordenar)
        try {
            List<File> directorios = op.listarFicheros(rutaPrueba, false, false, true);
            System.out.println("Directorios encontrados:");
            for (File dir : directorios) {
                System.out.println("- " + dir.getName());
            }
        } catch (NoEsUnDirectorioNoSePuedeListar | CarpetaVacia e) {
            System.err.println("Error al listar ficheros: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Error inesperado al listar ficheros: " + e.getMessage());
        }

        // 2. Probar crearDirectorios (crea un directorio nuevo)
        ArrayList<String> listaDirs = new ArrayList<>();
        listaDirs.add("NuevoDirectorio");
        try {
            int creados = op.crearDirectorios(rutaPrueba, listaDirs);
            System.out.println("Directorios creados: " + creados);
        } catch (Exception e) {
            System.err.println("Error al crear directorios: " + e.getMessage());
        }

        // 3. Probar cambiarExtensionFicheros (cambia .txt a .docx)
        try {
            int modificados = op.cambiarExtensionFicheros(rutaPrueba, ".txt", ".docx");
            System.out.println("Archivos modificados: " + modificados);
        } catch (Exception e) {
            System.err.println("Error al cambiar extensión: " + e.getMessage());
        }
    }
}
