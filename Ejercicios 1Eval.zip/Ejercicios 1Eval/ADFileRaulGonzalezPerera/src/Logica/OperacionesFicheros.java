package Logica;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class OperacionesFicheros {

    /**
     * Lista los ficheros o directorios dentro de una ruta dada.
     * Permite ordenar por nombre o tamaño, y filtrar solo directorios.
     *
     * @param ruta ruta del directorio a listar
     * @param ordenarPorNombre true para ordenar la lista por nombre
     * @param ordenarPorLongitud true para ordenar la lista por tamaño
     * @param soloDirectorios true para devolver solo directorios
     * @return lista de archivos/directorios filtrados y ordenados
     * @throws NoEsUnDirectorioNoSePuedeListar si la ruta no es un directorio válido
     * @throws CarpetaVacia si la carpeta está vacía
     */
    public List<File> listarFicheros(String ruta, boolean ordenarPorNombre, boolean ordenarPorLongitud, boolean soloDirectorios) throws NoEsUnDirectorioNoSePuedeListar, CarpetaVacia {
        File carpeta = new File(ruta);

        // Comprueba que la ruta existe y es un directorio
        if (!carpeta.exists() || !carpeta.isDirectory()) {
            throw new NoEsUnDirectorioNoSePuedeListar("La ruta no es un directorio válido.");
        }

        // Obtiene todos los archivos/directorios dentro de la carpeta
        File[] arrayArchivos = carpeta.listFiles();

        // Si no hay contenido, lanza excepción
        if (arrayArchivos == null || arrayArchivos.length == 0) {
            throw new CarpetaVacia("La carpeta está vacía.");
        }

        // Convierte el array a lista para facilitar manipulación
        List<File> lista = new ArrayList<>(Arrays.asList(arrayArchivos));

        // Si se indica ordenar por nombre, se usa un comparador basado en getName()
        if (ordenarPorNombre) {
            lista.sort((lf1, lf2) -> lf1.getName().compareTo(lf2.getName()));
        }

        // Si se indica ordenar por tamaño, se ordena con comparador de longitud (size)
        if (ordenarPorLongitud) {
            lista.sort((lf1, lf2) -> Long.compare(lf1.length(), lf2.length()));
        } else {
            // Si no es para ordenar por longitud, y soloDirectorios es true, se filtran para dejar solo directorios
            lista.removeIf(file -> !file.isDirectory());
        }

        // Devuelve la lista ya filtrada y/o ordenada
        return lista;
    }

    /**
     * Crea directorios en la ruta especificada según una lista de nombres.
     *
     * @param rutaOrigen ruta base donde se crearán los directorios
     * @param listaDirectorios lista con nombres de directorios a crear
     * @return número total de directorios creados con éxito
     * @throws Exception si la ruta de origen no existe o no es un directorio,
     *                   si algún directorio ya existe o si no se puede crear alguno
     */
    public int crearDirectorios(String rutaOrigen, ArrayList<String> listaDirectorios) throws Exception {
        ArrayList<String> lista = new ArrayList<>(listaDirectorios);
        File ruta = new File(rutaOrigen);
        int totalcreados = 0;

        // Verifica que la ruta existe y es directorio
        if (!ruta.exists() || !ruta.isDirectory()) {
            throw new Exception("la ruta de origen no es valida");
        }

        // Para cada nombre en la lista, crea un directorio nuevo dentro de la ruta origen
        for (String directorio : lista) {
            File DrectorioNuevo = new File(ruta, directorio);

            // Si el directorio ya existe, lanza excepción
            if (DrectorioNuevo.exists()) {
                throw new Exception("El directorio ya existe");
            }

            // Intenta crear el directorio y cuenta cuántos se crean exitosamente
            boolean creado = DrectorioNuevo.mkdir();
            if (creado) {
                totalcreados++;
            } else {
                throw new Exception("No se pudo crear el directorio " + directorio);
            }
        }
        return totalcreados;
    }

    /**
     * Cambia la extensión de todos los archivos dentro de una ruta que tengan una extensión dada.
     *
     * @param ruta ruta del directorio donde se modificarán archivos
     * @param extensionAntigua extensión a buscar para cambiar (debe incluir el punto, e.g. ".txt")
     * @param extensionNueva nueva extensión que se aplicará
     * @return número de archivos que fueron modificados exitosamente
     * @throws Exception si la ruta no existe, no se pueden listar archivos o falla el renombrado
     */
    public int cambiarExtensionFicheros(String ruta, String extensionAntigua, String extensionNueva) throws Exception {
        int numFicherosMod = 0;
        File rutaNueva = new File(ruta);

        // Verifica que la ruta existe
        if (!rutaNueva.exists()) {
            throw new Exception("La ruta no existe");
        }

        // Lista los archivos en la ruta
        File[] archivos = rutaNueva.listFiles();
        if (archivos == null) {
            throw new Exception("No se pudieron listar los archivos en la ruta.");
        }

        // Recorre cada archivo para cambiar su extensión si cumple la condición
        for (File archivo : archivos) {
            // Solo archivos (no directorios) y con la extensión antigua
            if (!archivo.isDirectory() && archivo.getName().endsWith(extensionAntigua)) {

                // Genera el nuevo nombre cambiando la extensión
                String nombreNuevo = archivo.getName().replace(extensionAntigua, extensionNueva);
                File archivoNuevo = new File(rutaNueva, nombreNuevo);

                // Renombra el archivo y cuenta cuantos se modifican
                boolean renombrado = archivo.renameTo(archivoNuevo);
                if (renombrado) {
                    numFicherosMod++;
                } else {
                    throw new Exception("No se pudo cambiar la extensión del archivo: " + archivo.getName());
                }
            }
        }
        return numFicherosMod;
    }

}
