package Logica;

/**
 * Excepción personalizada que indica que la carpeta está vacía.
 */
public class CarpetaVacia extends Throwable {
    // Variable para almacenar el mensaje de error
    String me;
    /**
     * Constructor que recibe un mensaje descriptivo de la excepción
     */
    public CarpetaVacia(String s) {
        this.me = s;
    }

}
