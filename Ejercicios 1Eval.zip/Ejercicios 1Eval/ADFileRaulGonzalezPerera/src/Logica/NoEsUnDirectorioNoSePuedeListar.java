package Logica;

/**
 * Excepción personalizada que indica que la ruta dada no es un directorio válido
 * y por lo tanto no se puede listar su contenido.
 */
public class NoEsUnDirectorioNoSePuedeListar extends Throwable {
    // Variable para almacenar el mensaje de error
    String me;
    /**
     * Constructor que recibe un mensaje descriptivo de la excepción.
     */
    public NoEsUnDirectorioNoSePuedeListar(String s) {
        this.me = s;
    }

    public String NoEsUnDirectorioNoSePuedeListar(String mensaje){
        return mensaje;
    }
}
