/**
 * Representa la capacidad de un vehículo para repostar combustible.
 */
public interface Repostable {
    void repostar(int cantidadLitros, char tipoCombustible);
}