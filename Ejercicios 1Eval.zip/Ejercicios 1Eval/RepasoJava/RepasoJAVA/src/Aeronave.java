/**
 * Representa una aeronave que puede volar.
 */
public class Aeronave extends Vehiculo implements Volar, Repostable {
    private int alturaVuelo;
    public boolean estaVolando;
    private String nombre;
    private int capacidadPasajeros;
    private int litrosDeposito;
    private int capacidadDeposito;
    private char tipoCombustible;

    public Aeronave(String matricula, double velocidadMaxima, String nombre) {
        super(matricula, velocidadMaxima);
        this.nombre = nombre;
        this.estaVolando = false;
    }

    public void despegar() { estaVolando = true; }
    public void ganarAltura(int cantidad) { alturaVuelo += cantidad; }
    public void perderAltura(int cantidad) { alturaVuelo -= cantidad; }
    public void repostar(int cantidadLitros, char tipoCombustible) {
        if (this.tipoCombustible == tipoCombustible && litrosDeposito + cantidadLitros <= capacidadDeposito) {
            litrosDeposito += cantidadLitros;
        }
    }
}