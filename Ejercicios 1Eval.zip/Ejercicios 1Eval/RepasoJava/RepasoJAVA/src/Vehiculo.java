/**
 * Clase base para todo tipo de vehículo.
 */
public abstract class Vehiculo {
    protected String matricula;
    protected double velocidad;
    protected double odometro;
    protected double velocidadMaxima;
    protected double posicionX;
    protected double posicionY;
    protected static int totalVehiculos;

    public Vehiculo(String matricula, double velocidadMaxima) {
        this.matricula = matricula;
        this.velocidadMaxima = velocidadMaxima;
        totalVehiculos++;
    }

    public double getOdometro() {
        return odometro;
    }

    public double getVelocidadMaxima() {
        return velocidadMaxima;
    }

    public String getMatricula() {
        return matricula;
    }

    public double[] getPosicionXY() {
        return new double[]{posicionX, posicionY};
    }
}