/**
 * Representa las funcionalidades de vuelo de una aeronave.
 */
public interface Volar {
    void despegar();
    void ganarAltura(int cantidad);
    void perderAltura(int cantidad);
}