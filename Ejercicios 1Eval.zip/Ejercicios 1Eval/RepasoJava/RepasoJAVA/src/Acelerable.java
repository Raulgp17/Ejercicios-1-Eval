/**
 * Representa la capacidad de acelerar o frenar de un vehículo.
 */
public interface Acelerable {
    void acelerar();
    void frenar();
}