/**
 * Representa un vehículo que puede ser cargado eléctricamente.
 */
public interface Electrico {
    void cargarBateria(int cantidad);
    int totalCargaBateria();
}