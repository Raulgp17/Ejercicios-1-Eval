/**
 * Representa una batería con carga eléctrica.
 */
public class Bateria {
    private int capacidadMaxima;
    private int estadoCarga;

    public Bateria(int capacidadMaxima) {
        this.capacidadMaxima = capacidadMaxima;
        this.estadoCarga = 0;
    }

    public void cargar(int cantidad) {
        estadoCarga = Math.min(capacidadMaxima, estadoCarga + cantidad);
    }

    public int getEstadoCarga() {
        return estadoCarga;
    }
}