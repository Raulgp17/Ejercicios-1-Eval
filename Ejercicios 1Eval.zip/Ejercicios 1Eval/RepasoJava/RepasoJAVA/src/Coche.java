/**
 * Clase abstracta para coches con atributos comunes.
 */
public abstract class Coche extends Vehiculo {
    protected int litrosDeposito;
    protected int capacidadDeposito;
    protected char tipoCombustible;

    public Coche(String matricula, double velocidadMaxima) {
        super(matricula, velocidadMaxima);
    }
}