import java.util.*;
import java.util.stream.*;

public class Utils {
    public static List<Vehiculo> ordenarPorVelocidadMaxima(List<Vehiculo> vehiculos) {
        return vehiculos.stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getVelocidadMaxima).reversed())
                .toList();
    }

    public static List<Aeronave> aeronavesVolando(List<Aeronave> aeronaves) {
        return aeronaves.stream()
                .filter(a -> a.estaVolando)
                .toList();
    }

    public static double promedioCapacidadCombustible(List<Coche> coches) {
        return coches.stream()
                .filter(c -> c.capacidadDeposito > 0)
                .mapToInt(c -> c.capacidadDeposito)
                .average().orElse(0);
    }

    public static Vehiculo mayorDistancia(List<Vehiculo> vehiculos) {
        return vehiculos.stream()
                .max(Comparator.comparingDouble(Vehiculo::getOdometro))
                .orElse(null);
    }

    public static List<CocheElectrico> filtrarCochesElectricosPorCarga(List<CocheElectrico> coches, int minCarga) {
        return coches.stream()
                .filter(c -> c.totalCargaBateria() > minCarga)
                .toList();
    }

    public static Map<String, Double> convertirAPolares(List<Vehiculo> vehiculos) {
        Map<String, Double> coordenadas = new HashMap<>();
        for (Vehiculo v : vehiculos) {
            double[] xy = v.getPosicionXY();
            double r = Math.sqrt(xy[0] * xy[0] + xy[1] * xy[1]);
            coordenadas.put(v.getMatricula(), r);
        }
        return coordenadas;
    }

    public static boolean cumplenVelocidadMinima(List<Vehiculo> vehiculos, double minima) {
        return vehiculos.stream()
                .allMatch(v -> v.getVelocidadMaxima() >= minima);
    }

    public static Map<Character, List<Coche>> agruparPorCombustible(List<Coche> coches) {
        return coches.stream().collect(Collectors.groupingBy(c -> c.tipoCombustible));
    }
}