/**
 * Representa un coche a combustible.
 */
public class CocheCombustible extends Coche implements Repostable {
    public CocheCombustible(String matricula, double velocidadMaxima) {
        super(matricula, velocidadMaxima);
    }

    public void repostar(int cantidadLitros, char tipoCombustible) {
        if (this.tipoCombustible == tipoCombustible && litrosDeposito + cantidadLitros <= capacidadDeposito) {
            litrosDeposito += cantidadLitros;
        }
    }
}