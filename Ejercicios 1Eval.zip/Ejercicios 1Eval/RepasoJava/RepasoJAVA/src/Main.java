import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<Vehiculo> vehiculos = new ArrayList<>();
        vehiculos.add(new CocheElectrico("ABC123", 120, 100));
        vehiculos.add(new CocheCombustible("DEF456", 150));
        vehiculos.add(new CocheHibrido("GHI789", 140));

        List<Vehiculo> ordenados = Utils.ordenarPorVelocidadMaxima(vehiculos);
        Vehiculo maxDistancia = Utils.mayorDistancia(vehiculos);
        Map<String, Double> coordenadasPolares = Utils.convertirAPolares(vehiculos);

        System.out.println("Vehículo con mayor distancia: " + (maxDistancia != null ? maxDistancia.getMatricula() : "N/A"));
        System.out.println("Coordenadas Polares:");
        coordenadasPolares.forEach((k, v) -> System.out.println(k + " -> " + v));
    }
}