/**
 * Representa un coche eléctrico.
 */
public class CocheElectrico extends Coche implements Electrico {
    private Bateria bateria;

    public CocheElectrico(String matricula, double velocidadMaxima, int capacidadBateria) {
        super(matricula, velocidadMaxima);
        this.bateria = new Bateria(capacidadBateria);
    }

    public void cargarBateria(int cantidad) {
        bateria.cargar(cantidad);
    }

    public int totalCargaBateria() {
        return bateria.getEstadoCarga();
    }
}