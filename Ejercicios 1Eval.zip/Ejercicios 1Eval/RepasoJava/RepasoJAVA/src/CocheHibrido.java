/**
 * Representa un coche híbrido.
 */
public class CocheHibrido extends Coche implements Repostable, Electrico {
    private Bateria bateria;

    public CocheHibrido(String matricula, double velocidadMaxima) {
        super(matricula, velocidadMaxima);
        this.bateria = new Bateria(100);
    }

    public void repostar(int cantidadLitros, char tipoCombustible) {
        if (this.tipoCombustible == tipoCombustible && litrosDeposito + cantidadLitros <= capacidadDeposito) {
            litrosDeposito += cantidadLitros;
        }
    }

    public void cargarBateria(int cantidad) {
        bateria.cargar(cantidad);
    }

    public int totalCargaBateria() {
        return bateria.getEstadoCarga();
    }
}